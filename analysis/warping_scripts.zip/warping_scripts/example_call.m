cfg                 = [];
cfg.dir_name        = cd;
cfg.path_to_ply     = 'Bearded guy.ply';
cfg.subject_number  = '0123';
FIL_3D_coreg(cfg);