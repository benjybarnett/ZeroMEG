    % Assign Weights Function
    function y = assignweights(x, w)
        
        % x is an indexing vector with the same number of arguments as w
        y = w(:)';
    end